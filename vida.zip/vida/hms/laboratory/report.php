<?php
session_start();
error_reporting(0);
include('include/config.php');
include('include/checklogin.php');
check_login();

if(isset($_POST['btn']))
{

$uid=$_POST['aadhaar_id'];
$_SESSION["aadhaar_id"]=$uid;
// $sql = "SELECT * FROM aadhaar_detail where aadhaar_id= '".$uid."'";
// $result = $con->query($sql);
// $row = $result->fetch_assoc();
// $sql=mysqli_query($con,"select * from aadhaar_detail where aadhaar id='$uid'");
// $row=mysqli_fetch_array($sql);
// echo $row['gender'];
$a=mysqli_query($con,"select * from aadhaar_detail where aadhaar_id='".$uid."' ");
$a_detail=mysqli_fetch_array($a);

$sql2 = "SELECT * FROM medical_info where aadhaar_id= '".$uid."'";
$result = $con->query($sql2);
 $row2 = $result->fetch_assoc();

$sql3 = "SELECT * FROM patient_history where aadhaar_id= '".$uid."'";
$result = $con->query($sql3);
global  $p_history;
$p_history = $result->fetch_assoc();
    	
	
$con->close();
}

// $con->close();


if(isset($_POST["upload"])){

	$uid=$_SESSION['aadhaar_id'];
	$sql3 = "SELECT * FROM patient_history where aadhaar_id= '".$uid."'";
	$result = $con->query($sql3);
	$p_history = $result->fetch_assoc();


	$lid=$_SESSION['id'];
	
	$case_id=$p_history['case_id'];
	$report=$p_history['report_name'];
	$date=date("y-m-d");

	$f_name=$_FILES['file']['name'];
	$temp_name=$_FILES['file']['tmp_name'];
    $file_store="uploads/";
    echo $f_name;
	#$file=file_get_contents($_FILES['fileToUpload']['tmp_name']);
	move_uploaded_file($temp_name,$file_store.$f_name);
	
	// $q="insert into laboratory_history(l_id,case_id,aadhaar_id,report,report_file,report_date) 
	// values ('$lid','$case_id','$uid','$report','$f_name','$date')";
	$q=mysqli_query($con,"insert into laboratory_history (l_id,case_id,aadhaar_id,report,report_file,report_date) values ('$lid','$case_id','$uid','$report','$f_name','$date')");
    #$sql="insert into laboratory_history(report_file) values ('$f_name')";
	
		if($q>0)
		{
		echo "<script>alert('Report added successfully');</script>";
		echo "<script>window.location.href ='report.php'</script>";
		}
		else{
		echo "<script>alert('error in file');</script>";
		echo "<script>window.location.href ='report.php'</script>";
		}

// else{
// 	echo "<script>alert('Error in Report Uploading ');</script>";
//     echo "<script>window.location.href ='report.php'</script>";

// }
}
	 
?>


<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Laboratory | Case</title>
		
		<link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
		<link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="vendor/themify-icons/themify-icons.min.css">
		<link href="vendor/animate.css/animate.min.css" rel="stylesheet" media="screen">
		<link href="vendor/perfect-scrollbar/perfect-scrollbar.min.css" rel="stylesheet" media="screen">
		<link href="vendor/switchery/switchery.min.css" rel="stylesheet" media="screen">
		<link href="vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.css" rel="stylesheet" media="screen">
		<link href="vendor/select2/select2.min.css" rel="stylesheet" media="screen">
		<link href="vendor/bootstrap-datepicker/bootstrap-datepicker3.standalone.min.css" rel="stylesheet" media="screen">
		<link href="vendor/bootstrap-timepicker/bootstrap-timepicker.min.css" rel="stylesheet" media="screen">
		<link rel="stylesheet" href="assets/css/styles.css">
		<link rel="stylesheet" href="assets/css/plugins.css">
		<link rel="stylesheet" href="assets/css/themes/theme-1.css" id="skin_color" />
	</head>
	<body>
		<div id="app">		
<?php include('include/sidebar.php');?>
<div class="app-content">
<?php include('include/header.php');?>
<div class="main-content" >
<div class="wrap-content container" id="container">
						<!-- //start: PAGE TITLE -->
<section id="page-title">
<div class="row">
<div class="col-sm-8">
<h1 class="mainTitle">Laboratory | Case</h1>
</div>
<ol class="breadcrumb">
<li>
<span>Laboratory</span>
</li>
<li class="active">
<span>Manage Case</span>
</li>
</ol>
</div>
</section> 

<form method="post">
<div class="container-fluid container-fullw bg-white">
<div class="row">

<div class="col-sm-6">
<label>Enter UID or Scan QR-Code</label><br>
<input type="text" name="aadhaar_id">
<input type="submit" name="btn" value="get value" >
<br>

<label style="margin-top: 15px;">Patient Details</label>
<div style=" background-color: #e1e1ea; width:80% ">
	 Patient Name :
    <label> <?php echo htmlentities($a_detail['f_name']); echo " " ; echo htmlentities($a_detail['l_name']);?></label>
	 
	 <br>
	 Blood Group : <label><?php echo htmlentities($row2[blood_group]);?></label>
</div>
<br>
<br>
<label style="margin-top: 15px;">Report Details</label>
<div style=" background-color: #e1e1ea; width:80% ">
	Creation Date:
	<label><?php echo htmlentities($p_history[creation_date]);?></label>
	<br>

	 Report name:<label> <?php echo htmlentities($p_history[report_name]);?></label>
	 <br>
	 <!-- <label> <?php echo htmlentities($_SESSION['id']);?></label> -->
	 <!-- Blood Group : <label>A+</label> -->
</div>
<br><br>
</form>
<form method="post" enctype="multipart/form-data">
     Upload Report :
	<input type="file" name="file">
    <input type="submit" value="upload" name="upload">
</form>
</div>	


<!-- <div class="col-md-12">
	<form role="form" method="post" name="search">

<div class="form-group">
<label for="doctorname">
Search by Name/Mobile No.
</label>
<input type="text" name="searchdata" id="searchdata" class="form-control" value="" required='true'>
</div>

<button type="submit" name="search" id="submit" class="btn btn-o btn-primary">
Search
</button>
 -->
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
			<!-- start: FOOTER -->
	<?php include('include/footer.php');?>
			<!-- end: FOOTER -->
		
			<!-- start: SETTINGS -->
	<?php include('include/setting.php');?>
			
			<!-- end: SETTINGS -->
		</div>
		<!-- start: MAIN JAVASCRIPTS -->
		<script src="vendor/jquery/jquery.min.js"></script>
		<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
		<script src="vendor/modernizr/modernizr.js"></script>
		<script src="vendor/jquery-cookie/jquery.cookie.js"></script>
		<script src="vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
		<script src="vendor/switchery/switchery.min.js"></script>
		<!-- end: MAIN JAVASCRIPTS -->
		<!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<script src="vendor/maskedinput/jquery.maskedinput.min.js"></script>
		<script src="vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
		<script src="vendor/autosize/autosize.min.js"></script>
		<script src="vendor/selectFx/classie.js"></script>
		<script src="vendor/selectFx/selectFx.js"></script>
		<script src="vendor/select2/select2.min.js"></script>
		<script src="vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
		<script src="vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
		<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<!-- start: CLIP-TWO JAVASCRIPTS -->
		<script src="assets/js/main.js"></script>
		<!-- start: JavaScript Event Handlers for this page -->
		<script src="assets/js/form-elements.js"></script>
		<script>
			jQuery(document).ready(function() {
				Main.init();
				FormElements.init();
			});
		</script>
		<!-- end: JavaScript Event Handlers for this page -->
		<!-- end: CLIP-TWO JAVASCRIPTS -->
	</body>
</html>
