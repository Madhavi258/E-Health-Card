<footer>
				<div class="footer-inner">
					
				</div>
			</footer>