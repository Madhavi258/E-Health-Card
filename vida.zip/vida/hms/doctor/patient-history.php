<?php
session_start();
error_reporting(0);
include('include/config.php');
include('include/checklogin.php');
check_login();
$count=1;
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Doctor | Patient History</title>

    <link
        href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic"
        rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendor/themify-icons/themify-icons.min.css">
    <link href="vendor/animate.css/animate.min.css" rel="stylesheet" media="screen">
    <link href="vendor/perfect-scrollbar/perfect-scrollbar.min.css" rel="stylesheet" media="screen">
    <link href="vendor/switchery/switchery.min.css" rel="stylesheet" media="screen">
    <link href="vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.css" rel="stylesheet" media="screen">
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="screen">
    <link href="vendor/bootstrap-datepicker/bootstrap-datepicker3.standalone.min.css" rel="stylesheet" media="screen">
    <link href="vendor/bootstrap-timepicker/bootstrap-timepicker.min.css" rel="stylesheet" media="screen">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/plugins.css">
    <link rel="stylesheet" href="assets/css/themes/theme-1.css" id="skin_color" />
</head>

<body>
    <div id="app">
        <?php include('include/sidebar.php');?>
        <div class="app-content">
            <?php include('include/header.php');?>
            <div class="main-content">
                <div class="wrap-content container" id="container">
                    <!-- start: PAGE TITLE -->
                    <section id="page-title">
                        <div class="row">
                            <div class="col-sm-8">
                                <h1 class="mainTitle">Doctor | Patient History</h1>
                            </div>
                            <ol class="breadcrumb">
                                <li>
                                    <span>Doctor</span>
                                </li>
                                <li class="active">
                                    <span>Patient History</span>
                                </li>
                            </ol>
                        </div>
                    </section>
                    <div class="container-fluid container-fullw bg-white">
                        <div class="row">
                            <div class="col-md-12">
                                <?php
                               $aadhaar_id=$_POST['uid'];
                               
                               $ret=mysqli_query($con,"select * from patient_history where aadhaar_id='$aadhaar_id'");
                              while ($mdetail=mysqli_fetch_array($ret)) {
                              $test1=mysqli_query($con,"select * from aadhaar_detail where aadhaar_id='$aadhaar_id' ");
                              $adetail=mysqli_fetch_array($test1);
                              
                              $test2=mysqli_query($con,"select * from patient where aadhaar_id='$aadhaar_id' ");
                              $pdetail=mysqli_fetch_array($test2);  
                              
                              $test3=mysqli_query($con,"select * from medical_info where aadhaar_id='$aadhaar_id' ");
                              $minfo=mysqli_fetch_array($test3);

                             $d_id=$mdetail['doctor_id'];
                             
                            $test4=mysqli_query($con,"select * from doctor_info where doctor_id='$d_id' ");
                        
                            $dinfo=mysqli_fetch_array($test4);

$userdob=$adetail['dob'];
$dob = new DateTime($userdob);
$now = new DateTime();
$difference = $now->diff($dob);
$age = $difference->y;
                               
                               if($count==1)
                               {
                               ?>

                                <table border="1" class="table table-bordered">
                                    <tr align="center">
                                        <td colspan="4" style="font-size:20px;color:blue">
                                            Patient Details</td>
                                    </tr>

                                    <tr>
                                        <th scope>Patient Name</th>
                                        <td><?php echo $adetail['f_name'].' '.$adetail['l_name'];?></td>
                                        <th>Patient Age</th>
                                        <td><?php  echo $age;?></td>
                                    </tr>
                                    <tr>
                                        <th scope>Patient Mobile Number</th>
                                        <td><?php  echo $adetail['mobile_no'];?></td>
                                        <th scope>Patient Email</th>
                                        <td><?php  echo $pdetail['email'];?></td>
                                    </tr>


                                    <?php
    if($minfo['allergy_name'] != 0 or $minfo['allergy_name']!='')
    { ?>
                                    <tr>
                                        <th scope>Patient Allergy</th>
                                        <td><?php  echo $minfo['allergy_name'];?></td>
                                        <th scope>Patient Allergy Medicine</th>
                                        <td><?php  echo $minfo['allergy_medicine'];?></td>

                                    </tr>
                                    <?php } ?>
                                    <tr>
                                        <th scope>Patient Blood Group</th>
                                        <td><?php  echo $minfo['blood_group'];?></td>
                                    </tr>

                                </table>
                                <?php 
                                $count = $count +1;
                            } ?>

                                <table border="1" class="table table-bordered">
                                    <tr align="center">
                                        <td colspan="4" style="font-size:20px;color:blue">
                                            Patient Medical Details</td>
                                    </tr>

                                    <tr>
                                        <th>Doctor Name</th>
                                        <td><?php  echo $dinfo['doctor_name'];?></td>
                                        <th>Contact No</th>
                                        <td><?php  echo $dinfo['contact_no'];?></td>
                                    </tr>

                                    <tr>
                                        <th scope>Disease Name</th>
                                        <td><?php echo $mdetail['disease'];?></td>
                                        <th scope>Disease Description</th>
                                        <td><?php  echo $mdetail['disease_description'];?></td>
                                    </tr>
                                    <tr>
                                        <th scope>Medicine</th>
                                        <td><?php  echo $mdetail['medicine'];?></td>
                                        <th scope>Medicine Quantity</th>
                                        <td><?php  echo $mdetail['medicine_quantity'];?></td>
                                    </tr>
                                    <tr>
                                        <th>Medicine Timing</th>
                                        <td><?php  echo $mdetail['medicine_timing'];?></td>
                                        <th>Last Visit Date</th>
                                        <td><?php  echo $mdetail['last_date'];?></td>
                                    </tr>

                                    <tr>
                                        <th>Height</th>
                                        <td><?php  echo $mdetail['height'];?></td>
                                        <th>Weight</th>
                                        <td><?php  echo $mdetail['weight'];?></td>
                                    </tr>

                                    

                                    
                                </table>



                                <?php }?>


                                <!-- start: FOOTER -->
                                <?php include('include/footer.php');?>
                                <!-- end: FOOTER -->

                                <!-- start: SETTINGS -->
                                <?php include('include/setting.php');?>

                                <!-- end: SETTINGS -->
                            </div>
                            <!-- start: MAIN JAVASCRIPTS -->
                            <script src="vendor/jquery/jquery.min.js"></script>
                            <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
                            <script src="vendor/modernizr/modernizr.js"></script>
                            <script src="vendor/jquery-cookie/jquery.cookie.js"></script>
                            <script src="vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
                            <script src="vendor/switchery/switchery.min.js"></script>
                            <!-- end: MAIN JAVASCRIPTS -->
                            <!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
                            <script src="vendor/maskedinput/jquery.maskedinput.min.js"></script>
                            <script src="vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
                            <script src="vendor/autosize/autosize.min.js"></script>
                            <script src="vendor/selectFx/classie.js"></script>
                            <script src="vendor/selectFx/selectFx.js"></script>
                            <script src="vendor/select2/select2.min.js"></script>
                            <script src="vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
                            <script src="vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
                            <!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
                            <!-- start: CLIP-TWO JAVASCRIPTS -->
                            <script src="assets/js/main.js"></script>
                            <!-- start: JavaScript Event Handlers for this page -->
                            <script src="assets/js/form-elements.js"></script>
                            <script>
                            jQuery(document).ready(function() {
                                Main.init();
                                FormElements.init();
                            });
                            </script>
                            <!-- end: JavaScript Event Handlers for this page -->
                            <!-- end: CLIP-TWO JAVASCRIPTS -->
</body>

</html>